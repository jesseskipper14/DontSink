using System.Collections.Generic;
using UnityEngine;
using WorldMap.Player.StarMap;

public sealed class WorldMapRouteOverlay : MonoBehaviour
{
    [Header("References")]
    [SerializeField] private WorldMapGraphGenerator generator;
    [SerializeField] private WorldMapRuntimeBinder runtimeBinder;
    [SerializeField] private WorldMapPlayerRef player;
    [SerializeField] private MapOverlayController mapOverlay; // or your selection system
    [SerializeField] private WorldMapNodeSelection selection;

    [Header("Behavior")]
    [SerializeField] private bool showLockedRoutes = true;
    [SerializeField] private bool rebuildOnGraphGenerated = true;

    [Header("UI Rendering (preferred for overlay)")]
    [Tooltip("If assigned, routes are drawn in UI space using UIEdgeGraphic. If null, world-space LineRenderer mode is used.")]
    [SerializeField] private UIEdgeGraphic uiEdges;

    [Tooltip("Map panel rect used for scaling node positions.")]
    [SerializeField] private RectTransform uiMapPanel;

    [Tooltip("Same container that node buttons are spawned under (determines anchoredPosition space).")]
    [SerializeField] private RectTransform uiNodeContainer;

    [Min(1f)]
    [SerializeField] private float uiThicknessPx = 3f;

    [Header("World Rendering (fallback)")]
    [SerializeField] private Material lineMaterial;
    [SerializeField] private float baseWidth = 0.06f;
    [SerializeField] private float zOffset = -0.5f;

    private string _lastCurrentNodeId;

    private readonly List<LineRenderer> _lines = new();

    // In WorldMapRouteOverlay
    [SerializeField] private WorldMapHoverController hoverController; // assign in inspector
    private WorldMapHoverState HoverState => hoverController != null ? hoverController.State : null;


    private void Reset()
    {
        generator = FindAnyObjectByType<WorldMapGraphGenerator>();
        runtimeBinder = FindAnyObjectByType<WorldMapRuntimeBinder>();
        player = FindAnyObjectByType<WorldMapPlayerRef>();
        selection = FindAnyObjectByType<WorldMapNodeSelection>();
    }

    private void OnEnable()
    {
        EnsureRefs();

        if (rebuildOnGraphGenerated && generator != null)
            generator.OnGraphGenerated += Rebuild;

        if (runtimeBinder != null)
            runtimeBinder.OnRuntimeBuilt += Rebuild;

        if (hoverController != null)
        {
            hoverController.HoverChanged -= Rebuild; // idempotent
            hoverController.HoverChanged += Rebuild;
        }

        if (mapOverlay != null)
        {
            mapOverlay.OverlayDirty -= Rebuild; // idempotent
            mapOverlay.OverlayDirty += Rebuild;
        }
    }

    private void OnDisable()
    {
        if (rebuildOnGraphGenerated && generator != null)
            generator.OnGraphGenerated -= Rebuild;

        if (runtimeBinder != null)
            runtimeBinder.OnRuntimeBuilt -= Rebuild;

        if (hoverController != null)
            hoverController.HoverChanged -= Rebuild;

        if (mapOverlay != null)
            mapOverlay.OverlayDirty -= Rebuild;
    }

    private void Start()
    {
        Rebuild();
    }

    private void Update()
    {
        if (player == null || player.State == null) return;

        var cur = player.State.currentNodeId;
        if (cur != _lastCurrentNodeId)
        {
            _lastCurrentNodeId = cur;
            Rebuild();
        }
    }

    [ContextMenu("Rebuild Route Overlay")]
    public void Rebuild()
    {
        // Always clear world lines; UI mode doesn't use them.
        ClearLines();

        if (generator?.graph == null) { ClearUI(); return; }
        if (runtimeBinder == null || !runtimeBinder.IsBuilt) { ClearUI(); return; }
        if (player == null || player.State == null) { ClearUI(); return; }

        // Current node runtime (authoritative)
        if (!runtimeBinder.Registry.TryGetByStableId(player.State.currentNodeId, out var currentRt) || currentRt == null)
        {
            ClearUI();
            return;
        }

        // Build hover anchors (these expand to all incident edges)
        var anchors = new HashSet<int>();

        var hover = HoverState;
        if (hover != null)
        {
            foreach (var a in hover.Pinned) anchors.Add(a);
            if (hover.HoveredNodeIndex >= 0) anchors.Add(hover.HoveredNodeIndex);
        }

        // Determine route target (selection/lock) for single-edge drawing
        int routeTargetIndex = -1;

        // Prefer locked destination if present (authoritative)
        var lockedStable = player.State.lockedDestinationNodeId;
        if (!string.IsNullOrEmpty(lockedStable) &&
            runtimeBinder.Registry.TryGetByStableId(lockedStable, out var lockedRt) &&
            lockedRt != null)
        {
            routeTargetIndex = lockedRt.NodeIndex;
        }
        else
        {
            // Otherwise use UI selection as the route target
            if (mapOverlay != null)
                routeTargetIndex = mapOverlay.SelectedNodeIndex;
            else if (selection != null)
                routeTargetIndex = selection.SelectedNodeId;
        }

        // Validate that the single-edge route actually exists (adjacent)
        bool hasRouteTargetEdge =
            routeTargetIndex >= 0 &&
            currentRt != null &&
            routeTargetIndex != currentRt.NodeIndex &&
            generator.graph.HasEdge(currentRt.NodeIndex, routeTargetIndex);

        // If we have neither hover anchors nor a valid route edge, draw nothing
        if (anchors.Count == 0 && !hasRouteTargetEdge)
        {
            ClearUI();
            return;
        }

        // UI mode
        if (uiEdges != null)
        {
            // pass hover anchors + route target
            RebuildUI(anchors, currentRt, hasRouteTargetEdge ? routeTargetIndex : -1);
            return;
        }

        // World fallback
        RebuildWorld(anchors, currentRt, hasRouteTargetEdge ? routeTargetIndex : -1);
    }

    // =========================
    // UI MODE
    // =========================

private void RebuildUI(HashSet<int> hoverAnchors, MapNodeRuntime currentRt, int routeTargetIndex)    {
        if (uiEdges == null || uiMapPanel == null || uiNodeContainer == null)
        {
            ClearUI();
            return;
        }

        var g = generator.graph;

        // Compute bounds in graph-space (same approach as your overlay rebuild)
        Vector2 min = g.nodes[0].position;
        Vector2 max = g.nodes[0].position;
        for (int i = 1; i < g.nodes.Count; i++)
        {
            var p = g.nodes[i].position;
            min = Vector2.Min(min, p);
            max = Vector2.Max(max, p);
        }

        Vector2 size = (max - min);
        if (size.x < 0.001f) size.x = 1f;
        if (size.y < 0.001f) size.y = 1f;

        Vector2 pad = size * 0.08f;
        min -= pad;
        max += pad;

        int lockedIndex = -1;
        var lockedStable = player.State.lockedDestinationNodeId;
        if (!string.IsNullOrEmpty(lockedStable) &&
            runtimeBinder.Registry.TryGetByStableId(lockedStable, out var lockedRt) &&
            lockedRt != null)
        {
            lockedIndex = lockedRt.NodeIndex;
        }

        int travelFromIndex = -1;
        int travelToIndex = -1;

        var gs = GameState.I;
        if (gs != null && gs.activeTravel != null)
        {
            var tp = gs.activeTravel;
            if (!string.IsNullOrEmpty(tp.fromNodeStableId) &&
                !string.IsNullOrEmpty(tp.toNodeStableId) &&
                runtimeBinder.Registry.TryGetByStableId(tp.fromNodeStableId, out var fromRt) && fromRt != null &&
                runtimeBinder.Registry.TryGetByStableId(tp.toNodeStableId, out var toRt) && toRt != null)
            {
                travelFromIndex = fromRt.NodeIndex;
                travelToIndex = toRt.NodeIndex;
            }
        }

        // Build segments in the SAME anchoredPosition space as node buttons
        var A = new List<Vector2>(256);
        var B = new List<Vector2>(256);
        var C = new List<Color32>(256);

        var edges = g.edges;
        var drawn = new HashSet<ulong>();

        for (int i = 0; i < edges.Count; i++)
        {
            var e = edges[i];

            ulong k = EdgeKey(e.a, e.b);
            if (!drawn.Add(k)) continue;

            bool isHoverEdge =
                hoverAnchors.Contains(e.a) || hoverAnchors.Contains(e.b);

            // If hovering/pinned, keep existing behavior: show all routes from those anchors.
            if (isHoverEdge)
            {
                // ok
            }
            else
            {
                // Not a hover-driven edge.
                // Only show the single current<->target edge (if any).
                if (routeTargetIndex < 0 || currentRt == null) continue;

                int cur = currentRt.NodeIndex;
                int tgt = routeTargetIndex;

                bool isRouteEdge =
                    (e.a == cur && e.b == tgt) ||
                    (e.b == cur && e.a == tgt);

                if (!isRouteEdge) continue;
            }

            if (!runtimeBinder.Registry.TryGetByIndex(e.a, out var aRt)) continue;
            if (!runtimeBinder.Registry.TryGetByIndex(e.b, out var bRt)) continue;

            var kState = StarMapVisualQuery.GetVisualState(
                player.State,
                aRt.StableId, aRt.ClusterId,
                bRt.StableId, bRt.ClusterId);

            Color32 c = kState switch
            {
                RouteKnowledgeState.Known => (Color32)Color.white,
                RouteKnowledgeState.Partial => (Color32)new Color(1f, 0.9f, 0.25f, 0.95f),
                RouteKnowledgeState.Rumored => (Color32)new Color(0.35f, 0.95f, 1f, 0.75f),
                _ => (Color32)new Color(1f, 0.25f, 0.25f, 0.85f)
            };

            bool isLockedEdge =
                lockedIndex >= 0 &&
                currentRt != null &&
                ((e.a == currentRt.NodeIndex && e.b == lockedIndex) ||
                 (e.b == currentRt.NodeIndex && e.a == lockedIndex));

            if (isLockedEdge)
                c = (Color32)Color.green;

            bool isTravelEdge =
                travelFromIndex >= 0 && travelToIndex >= 0 &&
                ((e.a == travelFromIndex && e.b == travelToIndex) ||
                 (e.b == travelFromIndex && e.a == travelToIndex));

            if (isTravelEdge)
                c = (Color32)Color.green;

            if (!showLockedRoutes && kState != RouteKnowledgeState.Known)
                continue;

            // Convert graph positions -> panel positions (anchoredPosition)
            Vector2 pa = GraphToPanel(g.nodes[e.a].position, min, max, uiMapPanel);
            Vector2 pb = GraphToPanel(g.nodes[e.b].position, min, max, uiMapPanel);

            A.Add(pa);
            B.Add(pb);
            C.Add(c);
        }

        uiEdges.lineThickness = uiThicknessPx;
        uiEdges.SetSegments(A, B, C);
    }

    private static Vector2 GraphToPanel(Vector2 graphPos, Vector2 min, Vector2 max, RectTransform mapPanel)
    {
        Vector2 size = max - min;
        float nx = (graphPos.x - min.x) / (size.x <= 0.0001f ? 1f : size.x);
        float ny = (graphPos.y - min.y) / (size.y <= 0.0001f ? 1f : size.y);

        float x = (nx - 0.5f) * mapPanel.rect.width;
        float y = (ny - 0.5f) * mapPanel.rect.height;
        return new Vector2(x, y);
    }

    private void ClearUI()
    {
        if (uiEdges != null)
            uiEdges.SetSegments(_empty, _empty);
    }

    private static readonly List<Vector2> _empty = new List<Vector2>(0);

    // =========================
    // WORLD MODE (fallback)
    // =========================

    private void RebuildWorld(HashSet<int> hoverAnchors, MapNodeRuntime currentRt, int routeTargetIndex)
    {
        var g = generator.graph;
        var edges = g.edges;
        var drawn = new HashSet<ulong>();

        for (int i = 0; i < edges.Count; i++)
        {
            var e = edges[i];

            ulong k = EdgeKey(e.a, e.b);
            if (!drawn.Add(k))
                continue;

            bool isHoverEdge =
                hoverAnchors.Contains(e.a) || hoverAnchors.Contains(e.b);

            // If hovering/pinned, keep existing behavior: show all routes from those anchors.
            if (isHoverEdge)
            {
                // ok
            }
            else
            {
                // Not a hover-driven edge.
                // Only show the single current<->target edge (if any).
                if (routeTargetIndex < 0 || currentRt == null) continue;

                int cur = currentRt.NodeIndex;
                int tgt = routeTargetIndex;

                bool isRouteEdge =
                    (e.a == cur && e.b == tgt) ||
                    (e.b == cur && e.a == tgt);

                if (!isRouteEdge) continue;
            }

            if (!runtimeBinder.Registry.TryGetByIndex(e.a, out var aRt)) continue;
            if (!runtimeBinder.Registry.TryGetByIndex(e.b, out var bRt)) continue;

            var kState = StarMapVisualQuery.GetVisualState(
                player.State,
                aRt.StableId, aRt.ClusterId,
                bRt.StableId, bRt.ClusterId);

            if (!showLockedRoutes && kState != RouteKnowledgeState.Known)
                continue;

            var lr = CreateLine($"Route_{e.a}_{e.b}");

            lr.positionCount = 2;
            lr.SetPosition(0, WithZ(aRt.transform.position));
            lr.SetPosition(1, WithZ(bRt.transform.position));

            lr.widthMultiplier = baseWidth;

            Color c = kState switch
            {
                RouteKnowledgeState.Known => Color.white,
                RouteKnowledgeState.Partial => new Color(1f, 0.9f, 0.25f, 0.95f),
                RouteKnowledgeState.Rumored => new Color(0.35f, 0.95f, 1f, 0.75f),
                _ => new Color(1f, 0.25f, 0.25f, 0.85f)
            };

            lr.startColor = c;
            lr.endColor = c;

            _lines.Add(lr);
        }
    }

    private Vector3 WithZ(Vector3 p) { p.z = zOffset; return p; }

    private LineRenderer CreateLine(string name)
    {
        var go = new GameObject(name);
        go.transform.SetParent(transform, worldPositionStays: true);

        var lr = go.AddComponent<LineRenderer>();
        lr.useWorldSpace = true;
        lr.material = lineMaterial != null ? lineMaterial : new Material(Shader.Find("Sprites/Default"));
        lr.numCapVertices = 2;
        lr.numCornerVertices = 2;

        return lr;
    }

    private void ClearLines()
    {
        for (int i = 0; i < _lines.Count; i++)
            if (_lines[i] != null)
                Destroy(_lines[i].gameObject);

        _lines.Clear();
    }

    private static ulong EdgeKey(int a, int b)
    {
        uint x = (uint)Mathf.Min(a, b);
        uint y = (uint)Mathf.Max(a, b);
        return ((ulong)x << 32) | y;
    }

    private void EnsureRefs()
    {
        if (generator == null) generator = FindAnyObjectByType<WorldMapGraphGenerator>();
        if (runtimeBinder == null) runtimeBinder = FindAnyObjectByType<WorldMapRuntimeBinder>();
        if (player == null) player = FindAnyObjectByType<WorldMapPlayerRef>(FindObjectsInactive.Include);
        if (mapOverlay == null) mapOverlay = FindAnyObjectByType<MapOverlayController>(FindObjectsInactive.Include);
        if (hoverController == null) hoverController = FindAnyObjectByType<WorldMapHoverController>(FindObjectsInactive.Include);
    }
}
