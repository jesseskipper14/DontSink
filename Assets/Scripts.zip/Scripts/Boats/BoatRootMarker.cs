using UnityEngine;

[DisallowMultipleComponent]
public sealed class BoatRootMarker : MonoBehaviour
{
    // Intentionally empty.
    // Exists so systems can reliably find the boat root without name hacks.
}