using UnityEngine;
using UnityEngine.SceneManagement;

public sealed class BoatSceneController : MonoBehaviour
{
    [SerializeField] private string nodeSceneName = "NodeScene";

    public TravelPayload Payload { get; private set; }

    private void Start()
    {
        Payload = GameState.I.activeTravel;
        if (Payload == null)
        {
            Debug.LogError("BoatScene: No active travel payload. Returning to node scene.");
            SceneManager.LoadScene(nodeSceneName);
            return;
        }

        // TODO: generate boat run content from Payload.from/to + seed
    }

    // Debug escape hatch: arrive at source (abort travel)
    public void DebugDockToSource()
    {
        var gs = GameState.I;
        gs.player.currentNodeId = Payload.fromNodeStableId;
        gs.ClearTravel();
        SceneManager.LoadScene(nodeSceneName);
    }

    // Debug escape hatch: arrive at destination (complete travel)
    public void DebugDockToDestination()
    {
        var gs = GameState.I;
        gs.player.currentNodeId = Payload.toNodeStableId;
        gs.ClearTravel();
        SceneManager.LoadScene(nodeSceneName);
    }
}
