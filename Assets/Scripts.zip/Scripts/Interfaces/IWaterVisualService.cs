public interface IWaterVisualService
{
    void Initialize(IBrightnessService brightnessService);
}
