public interface IController
{
    void Tick(IForceBody body);
}
