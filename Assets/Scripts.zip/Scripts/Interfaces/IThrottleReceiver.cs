public interface IThrottleReceiver
{
    /// value in [-1, +1]
    void SetThrottle(float value);
}
