public interface ILocalPlayerAuthority
{
    bool IsLocal { get; }
}