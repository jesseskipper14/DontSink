public interface ISubmersionProvider
{
    float SubmergedFraction { get; }
}
