public interface IForceProvider
{
    void ApplyForces(IForceBody body);
}
