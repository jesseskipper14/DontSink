public interface ISkyVisualService
{
    void Initialize(ITimeOfDayService timeService, IBrightnessService brightnessService);
}
