public interface ICelestialBodyService
{
    void Initialize(ITimeOfDayService timeService);
}
