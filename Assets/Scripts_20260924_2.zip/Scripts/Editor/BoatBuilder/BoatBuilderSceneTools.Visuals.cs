#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

public static partial class BoatBuilderSceneTools
{

    // Keep side/bottom escape boundaries close to the actual boat so an item
    // cannot sit fully outside the hull while still loading Boat mass.
    private const float DefaultItemContainmentHorizontalPadding = 0.10f;
    private const float DefaultItemContainmentBottomPadding = 0.10f;

    private static GameObject CreateGeneratedItemContainmentZone(
        Transform boatRoot,
        Transform parent)
    {
        if (boatRoot == null)
        {
            Debug.LogError(
                "[BoatBuilder] Cannot create BoatItemContainmentZone without a BoatRoot.");
            return null;
        }

        GameObject placed =
            new GameObject("BoatItemContainmentZone");

        Undo.RegisterCreatedObjectUndo(
            placed,
            "Create Boat Item Containment Zone");

        Transform targetParent =
            parent != null
                ? parent
                : GetOrCreateBoatCategoryRoot(
                    boatRoot,
                    BoatVisualCategory.Volume);

        Undo.SetTransformParent(
            placed.transform,
            targetParent != null ? targetParent : boatRoot,
            "Parent Boat Item Containment Zone");

        placed.transform.localPosition = Vector3.zero;
        placed.transform.localRotation = Quaternion.identity;
        placed.transform.localScale = Vector3.one;

        BoxCollider2D box =
            Undo.AddComponent<BoxCollider2D>(placed);

        box.isTrigger = true;

        Undo.AddComponent<BoatItemContainmentZone>(placed);

        AutoFitItemContainmentZone(
            boatRoot,
            placed,
            DefaultItemContainmentHorizontalPadding,
            DefaultItemContainmentBottomPadding);

        Selection.activeGameObject = placed;
        EditorGUIUtility.PingObject(placed);

        EditorUtility.SetDirty(placed);
        EditorUtility.SetDirty(box);
        EditorSceneManager.MarkSceneDirty(
            EditorSceneManager.GetActiveScene());

        return placed;
    }

    private static void AutoFitItemContainmentZone(
        Transform boatRoot,
        GameObject placed,
        float horizontalPadding,
        float bottomPadding)
    {
        if (boatRoot == null || placed == null)
            return;

        BoxCollider2D box =
            placed.GetComponent<BoxCollider2D>();

        if (box == null)
        {
            Debug.LogError(
                "[BoatBuilder] BoatItemContainmentZone has no BoxCollider2D to auto-fit.",
                placed);
            return;
        }

        // Use the same visual-bounds basis as BoardedVolume authoring, but with
        // intentionally modest margins. This is a loose-item physical containment
        // envelope, not the tall gameplay boarding envelope.
        Renderer[] renderers =
            boatRoot.GetComponentsInChildren<Renderer>(true)
                .Where(
                    r =>
                        r != null &&
                        !r.transform.IsChildOf(placed.transform))
                .ToArray();

        if (renderers.Length == 0)
        {
            Debug.LogError(
                "[BoatBuilder] Could not auto-fit BoatItemContainmentZone: no renderers found under BoatRoot.",
                boatRoot);
            return;
        }

        Bounds bounds = renderers[0].bounds;

        for (int i = 1; i < renderers.Length; i++)
            bounds.Encapsulate(renderers[i].bounds);

        horizontalPadding =
            Mathf.Max(
                0f,
                horizontalPadding);

        bottomPadding =
            Mathf.Max(
                0f,
                bottomPadding);

        float left =
            bounds.min.x -
            horizontalPadding;

        float right =
            bounds.max.x +
            horizontalPadding;

        float bottom =
            bounds.min.y -
            bottomPadding;

        // Cargo stacks can legitimately extend far above the visible hull.
        // Use the BoardedVolume's authored upper boundary as the containment
        // ceiling instead of inventing a second unrelated "how tall is aboard?"
        // number.
        float top =
            bounds.max.y;

        BoatBoardedVolume boardedVolume =
            boatRoot.GetComponentInChildren<BoatBoardedVolume>(
                true);

        Collider2D boardedCollider =
            boardedVolume != null
                ? boardedVolume.GetComponent<Collider2D>()
                : null;

        if (boardedCollider != null &&
            boardedCollider.enabled)
        {
            top =
                Mathf.Max(
                    top,
                    boardedCollider.bounds.max.y);
        }
        else
        {
            Debug.LogWarning(
                "[BoatBuilder] Auto-fitting BoatItemContainmentZone without a usable " +
                "BoatBoardedVolume Collider2D. Falling back to the boat's visual top. " +
                "BoardedVolume is a required piece and should normally be placed first.",
                boatRoot);
        }

        Bounds fittedBounds =
            new Bounds();

        fittedBounds.SetMinMax(
            new Vector3(
                left,
                bottom,
                bounds.min.z),
            new Vector3(
                right,
                top,
                bounds.max.z));

        Undo.RecordObject(
            placed.transform,
            "Auto-fit Boat Item Containment Zone");

        Undo.RecordObject(
            box,
            "Resize Boat Item Containment Zone");

        placed.transform.position =
            new Vector3(
                fittedBounds.center.x,
                fittedBounds.center.y,
                placed.transform.position.z);

        // _Volumes is authored with identity local transform under BoatRoot, so the
        // BoatRoot conversion keeps the generated box aligned with the boat.
        Vector2 localSize =
            boatRoot.InverseTransformVector(
                fittedBounds.size);

        box.offset = Vector2.zero;
        box.size =
            new Vector2(
                Mathf.Abs(localSize.x),
                Mathf.Abs(localSize.y));

        box.isTrigger = true;

        EditorUtility.SetDirty(placed.transform);
        EditorUtility.SetDirty(box);
    }

    private static void AutoFitBoardedVolume(Transform boatRoot, GameObject placed, float padding, float extraUp, float extraDown)
    {
        if (boatRoot == null || placed == null)
            return;

        var box = placed.GetComponent<BoxCollider2D>();
        if (box == null)
        {
            Debug.LogWarning("[BoatBuilder] BoardedVolume placed, but no BoxCollider2D found to auto-fit.", placed);
            return;
        }

        var renderers = boatRoot.GetComponentsInChildren<Renderer>(true)
            .Where(r => r != null && r.gameObject != placed)
            .ToArray();

        if (renderers.Length == 0)
        {
            Debug.LogWarning("[BoatBuilder] Could not auto-fit BoardedVolume: no renderers found under boat root.", boatRoot);
            return;
        }

        Bounds bounds = renderers[0].bounds;
        for (int i = 1; i < renderers.Length; i++)
            bounds.Encapsulate(renderers[i].bounds);

        bounds.Expand(new Vector3(padding * 2f, padding * 2f, 0f));
        bounds.min += new Vector3(0f, -extraDown, 0f);
        bounds.max += new Vector3(0f, extraUp, 0f);

        Undo.RecordObject(placed.transform, "Auto-fit BoardedVolume");
        Undo.RecordObject(box, "Resize BoardedVolume");

        placed.transform.position = new Vector3(bounds.center.x, bounds.center.y, placed.transform.position.z);

        Vector2 localSize = boatRoot.InverseTransformVector(bounds.size);
        box.offset = Vector2.zero;
        box.size = new Vector2(Mathf.Abs(localSize.x), Mathf.Abs(localSize.y));

        EditorUtility.SetDirty(placed.transform);
        EditorUtility.SetDirty(box);
    }

    private static Transform ResolvePlacementParentForTool(
        BoatBuilderWindow.Tool tool,
        Transform boatRoot)
    {
        if (boatRoot == null)
            return null;

        return tool switch
        {
            // Exterior shell / visual occluder
            BoatBuilderWindow.Tool.ExteriorShell =>
                GetOrCreateBoatCategoryRoot(boatRoot, BoatVisualCategory.ExteriorShell),

            // Hull/body structural visuals
            BoatBuilderWindow.Tool.HullSegment =>
                GetOrCreateBoatCategoryRoot(boatRoot, BoatVisualCategory.Hull),

            BoatBuilderWindow.Tool.Wall =>
                GetOrCreateBoatCategoryRoot(boatRoot, BoatVisualCategory.Hull),

            // Interior simulation/visuals
            BoatBuilderWindow.Tool.CompartmentRect =>
                GetOrCreateBoatCategoryRoot(boatRoot, BoatVisualCategory.Interior),

            BoatBuilderWindow.Tool.Ladder =>
                GetOrCreateBoatCategoryRoot(boatRoot, BoatVisualCategory.Interior),

            BoatBuilderWindow.Tool.Stairs =>
                GetOrCreateBoatCategoryRoot(boatRoot, BoatVisualCategory.Interior),

            BoatBuilderWindow.Tool.Ledge =>
                GetOrCreateBoatCategoryRoot(boatRoot, BoatVisualCategory.Interior),

            // Exterior deck objects
            BoatBuilderWindow.Tool.Deck =>
                GetOrCreateBoatCategoryRoot(boatRoot, BoatVisualCategory.ExteriorDeck),

            BoatBuilderWindow.Tool.Hatch =>
                GetOrCreateBoatCategoryRoot(boatRoot, BoatVisualCategory.ExteriorDeck),

            BoatBuilderWindow.Tool.Door =>
                GetOrCreateBoatCategoryRoot(boatRoot, BoatVisualCategory.Interior),

            BoatBuilderWindow.Tool.PilotChair =>
                GetOrCreateBoatCategoryRoot(boatRoot, BoatVisualCategory.Gameplay),

            // Volumes/triggers
            BoatBuilderWindow.Tool.BoardedVolume =>
                GetOrCreateBoatCategoryRoot(boatRoot, BoatVisualCategory.Volume),

            BoatBuilderWindow.Tool.ItemContainmentZone =>
                GetOrCreateBoatCategoryRoot(boatRoot, BoatVisualCategory.Volume),

            BoatBuilderWindow.Tool.BoatVisibilityZone =>
                GetOrCreateBoatCategoryRoot(boatRoot, BoatVisualCategory.Volume),

            // Gameplay helpers/interactables
            BoatBuilderWindow.Tool.PlayerSpawnPoint =>
                GetOrCreateBoatCategoryRoot(boatRoot, BoatVisualCategory.Gameplay),

            BoatBuilderWindow.Tool.BoatBoardObject =>
                GetOrCreateBoatCategoryRoot(boatRoot, BoatVisualCategory.Gameplay),

            BoatBuilderWindow.Tool.DeckBoardZone =>
                GetOrCreateBoatCategoryRoot(boatRoot, BoatVisualCategory.Gameplay),

            BoatBuilderWindow.Tool.MapTable =>
                GetOrCreateBoatCategoryRoot(boatRoot, BoatVisualCategory.Gameplay),

            BoatBuilderWindow.Tool.MoneyChestSlot =>
                GetOrCreateBoatCategoryRoot(boatRoot, BoatVisualCategory.Gameplay),

            BoatBuilderWindow.Tool.Hardpoint =>
                GetOrCreateBoatCategoryRoot(boatRoot, BoatVisualCategory.Gameplay),

            BoatBuilderWindow.Tool.TurretControllerChair =>
                GetOrCreateBoatCategoryRoot(boatRoot, BoatVisualCategory.Gameplay),

            // Cargo / securing
            BoatBuilderWindow.Tool.CargoZoneFloor =>
                GetOrCreateBoatCategoryRoot(boatRoot, BoatVisualCategory.Cargo),

            BoatBuilderWindow.Tool.BoatCleat =>
                GetOrCreateBoatCategoryRoot(boatRoot, BoatVisualCategory.Cargo),

            _ => boatRoot
        };
    }

    private static Transform GetOrCreateBoatCategoryRoot(Transform boatRoot, BoatVisualCategory category)
    {
        if (boatRoot == null)
            return null;

        string childName = category switch
        {
            BoatVisualCategory.ExteriorShell => "_Exterior",
            BoatVisualCategory.Interior => "_Interior",
            BoatVisualCategory.ExteriorDeck => "_Deck",
            BoatVisualCategory.Gameplay => "_Gameplay",
            BoatVisualCategory.Volume => "_Volumes",
            BoatVisualCategory.AlwaysVisible => "_AlwaysVisible",
            BoatVisualCategory.Hull => "_Hull",
            BoatVisualCategory.Cargo => "_Cargo",
            _ => "_Misc"
        };

        Transform existing = boatRoot.Find(childName);
        if (existing != null)
            return existing;

        GameObject go = new GameObject(childName);
        Undo.RegisterCreatedObjectUndo(go, $"Create boat category root {childName}");

        Transform t = go.transform;
        Undo.SetTransformParent(t, boatRoot, $"Parent {childName} to BoatRoot");

        t.localPosition = Vector3.zero;
        t.localRotation = Quaternion.identity;
        t.localScale = Vector3.one;

        EditorUtility.SetDirty(go);
        EditorSceneManager.MarkSceneDirty(boatRoot.gameObject.scene);

        return t;
    }

    private static void InitializePlacedVisualMarker(GameObject placed, BoatVisualCategory category)
    {
        if (placed == null)
            return;

        BoatVisualMarker marker = placed.GetComponent<BoatVisualMarker>();
        if (marker == null)
        {
            marker = placed.AddComponent<BoatVisualMarker>();
            Undo.RegisterCreatedObjectUndo(marker, "Add Boat Visual Marker");
        }

        Undo.RecordObject(marker, "Configure Boat Visual Marker");
        marker.EditorSetCategory(category);

        EditorUtility.SetDirty(marker);
    }

    private static void InitializePlacedStair(GameObject placed, bool ascendRight)
    {
        if (placed == null)
            return;

        StairSlopeAuthoring stair = placed.GetComponent<StairSlopeAuthoring>();
        if (stair == null)
        {
            Debug.LogWarning("[BoatBuilder] Placed stair prefab has no StairSlopeAuthoring.", placed);
            return;
        }

        Undo.RecordObject(stair, "Configure Stair Orientation");

        SerializedObject stairSO = new SerializedObject(stair);
        SerializedProperty ascendProp = stairSO.FindProperty("ascendRight");

        if (ascendProp != null)
        {
            ascendProp.boolValue = ascendRight;
            stairSO.ApplyModifiedPropertiesWithoutUndo();
            EditorUtility.SetDirty(stair);
        }

        // Force immediate re-apply in editor so collider/mesh/trigger update now.
        stair.Apply();

        Selection.activeGameObject = placed;
    }

    public static void AutoFitBoatGeometryFromVisualRenderers(Transform boatRoot)
    {
        if (boatRoot == null)
        {
            Debug.LogWarning("[BoatBuilder] Cannot auto-fit boat geometry: BoatRoot is null.");
            return;
        }

        Boat boat = boatRoot.GetComponent<Boat>();
        if (boat == null)
            boat = boatRoot.GetComponentInParent<Boat>();

        if (boat == null)
        {
            Debug.LogWarning($"[BoatBuilder] Cannot auto-fit boat geometry: no Boat component found for '{boatRoot.name}'.", boatRoot);
            return;
        }

        boat.EditorAutoFitGeometryFromVisualRenderers();

        EditorUtility.SetDirty(boat);
        EditorSceneManager.MarkSceneDirty(EditorSceneManager.GetActiveScene());
    }

    public static void SetExteriorShellEditorHidden(Transform boatRoot, bool hidden)
    {
        if (boatRoot == null)
            return;

        List<GameObject> targets = CollectExteriorShellVisibilityTargets(boatRoot);

        for (int i = 0; i < targets.Count; i++)
        {
            GameObject go = targets[i];
            if (go == null)
                continue;

            if (hidden)
                SceneVisibilityManager.instance.Hide(go, true);
            else
                SceneVisibilityManager.instance.Show(go, true);
        }

        SceneView.RepaintAll();
    }

    private static List<GameObject> CollectExteriorShellVisibilityTargets(Transform boatRoot)
    {
        List<GameObject> result = new List<GameObject>();
        HashSet<GameObject> seen = new HashSet<GameObject>();

        AddUniqueVisibilityTarget(result, seen, boatRoot.Find("_Exterior"));
        AddUniqueVisibilityTarget(result, seen, boatRoot.Find("Exterior"));

        BoatVisualMarker[] markers = boatRoot.GetComponentsInChildren<BoatVisualMarker>(true);
        for (int i = 0; i < markers.Length; i++)
        {
            BoatVisualMarker marker = markers[i];
            if (marker == null)
                continue;

            if (marker.Category != BoatVisualCategory.ExteriorShell)
                continue;

            AddUniqueVisibilityTarget(result, seen, marker.transform);
        }

        return result;
    }

    private static void AddUniqueVisibilityTarget(
        List<GameObject> result,
        HashSet<GameObject> seen,
        Transform target)
    {
        if (target == null)
            return;

        GameObject go = target.gameObject;
        if (go == null)
            return;

        if (!seen.Add(go))
            return;

        result.Add(go);
    }

    private static void InitializePlacedVisibilityZone(
    GameObject placed,
    Transform boatRoot,
    BoatVisibilityMode mode,
    int priority)
    {
        if (placed == null)
            return;

        BoatVisibilityZone zone = placed.GetComponent<BoatVisibilityZone>();
        if (zone == null)
            zone = placed.GetComponentInChildren<BoatVisibilityZone>(true);

        if (zone == null)
        {
            Debug.LogWarning("[BoatBuilder] Placed visibility zone prefab has no BoatVisibilityZone component.", placed);
            return;
        }

        BoatVisualStateController controller = null;

        if (boatRoot != null)
        {
            controller = boatRoot.GetComponent<BoatVisualStateController>();
            if (controller == null)
                controller = boatRoot.GetComponentInChildren<BoatVisualStateController>(true);
        }

        Undo.RecordObject(zone, "Configure Boat Visibility Zone");
        zone.EditorConfigure(mode, priority, controller);

        Collider2D col = zone.GetComponent<Collider2D>();
        if (col != null)
        {
            Undo.RecordObject(col, "Configure Boat Visibility Zone Collider");
            col.isTrigger = true;
            EditorUtility.SetDirty(col);
        }

        string modeName = mode.ToString();
        string objectName = $"VisibilityZone_{modeName}";

        Undo.RecordObject(placed, "Rename Boat Visibility Zone");
        placed.name = objectName;

        InitializePlacedVisualMarker(placed, BoatVisualCategory.Volume);

        EditorUtility.SetDirty(zone);
        EditorUtility.SetDirty(placed);
        EditorSceneManager.MarkSceneDirty(EditorSceneManager.GetActiveScene());

        if (controller == null)
        {
            Debug.LogWarning(
                "[BoatBuilder] Visibility zone placed, but no BoatVisualStateController found on/under boat root. " +
                "Zone will try to auto-resolve at runtime, but you probably want the controller on BoatRoot.",
                placed);
        }
    }

    private static void InitializeCompartmentInteriorVisibilityZone(
        GameObject placed,
        Transform boatRoot)
    {
        if (placed == null || boatRoot == null)
            return;

        CompartmentRectAuthoring authoring =
            placed.GetComponent<CompartmentRectAuthoring>() ??
            placed.GetComponentInChildren<CompartmentRectAuthoring>(true);

        if (authoring == null)
            return;

        BoatVisualStateController controller =
            boatRoot.GetComponent<BoatVisualStateController>() ??
            boatRoot.GetComponentInChildren<BoatVisualStateController>(true);

        authoring.EditorEnsureInteriorVisibilityZone(controller);

        InitializePlacedVisualMarker(placed, BoatVisualCategory.Interior);

        EditorUtility.SetDirty(placed);
        EditorSceneManager.MarkSceneDirty(EditorSceneManager.GetActiveScene());

        if (controller == null)
        {
            Debug.LogWarning(
                "[BoatBuilder] Generated compartment interior visibility zone, but no BoatVisualStateController was found on/under BoatRoot.",
                placed);
        }
    }
}
#endif
