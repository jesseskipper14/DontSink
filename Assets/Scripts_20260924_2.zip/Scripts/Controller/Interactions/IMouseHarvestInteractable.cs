public interface IMouseHarvestInteractable
{
}