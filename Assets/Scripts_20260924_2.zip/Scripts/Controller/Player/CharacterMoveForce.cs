using Survival.Attributes;
using UnityEngine;

/// <summary>
/// Consumes intent and applies forces/impulses via IForceBody.
/// MP-safe: intent can come from local input or network.
/// Fix: latches JumpPressed so Update-pulse input isn't missed by FixedUpdate.
/// Adds: movement scaling based on body rotation.
/// </summary>
[RequireComponent(typeof(CharacterMotor2D))]
public class CharacterMoveForce : MonoBehaviour, IOrderedForceProvider
{
    public bool Enabled => enabledFlag;
    public int Priority => priority;

    [SerializeField] private bool enabledFlag = true;
    [SerializeField] private int priority = 100;

    [Header("Attributes")]
    [SerializeField] private PlayerAttributeState attributes;

    [Header("Movement Fallover Penalty")]
    [Tooltip("At this angle from upright (deg), movement reaches crawl speed.")]
    [SerializeField] private float crawlAngleDeg = 90f;

    [Tooltip("Beyond this angle from upright (deg), movement is disabled (e.g. inverted).")]
    [SerializeField] private float disabledAngleDeg = 100f;

    [Header("Sprint (Land)")]
    [SerializeField, Min(1f)] private float sprintSpeedMultiplier = 1.5f;
    [SerializeField, Min(1f)] private float sprintForceMultiplier = 1.35f;

    [Tooltip("Movement multiplier at/near sideways (crawl).")]
    [Range(0f, 1f)]
    [SerializeField] private float crawlMoveMultiplier = 0.2f;

    [Header("Water Wading (non-swimming)")]
    [SerializeField, Range(0f, 1f)]
    private float wadeMinMoveMultiplier = 0.4f;

    [Header("Jump Angle Gate")]
    [SerializeField] private float maxJumpAngleDeg = 60f; // > this from upright disables jump

    [Header("Jump Debug")]
    [SerializeField] private bool debugJumpDecisions = true;

    [Header("Jump + Energy")]
    [SerializeField] private float jumpExertionImpulse01 = 0.18f;

    [SerializeField, Range(0f, 1f)]
    private float jumpAuthorityAtLowEnergy = 0.65f; // jump strength at lowEnergyThreshold

    [SerializeField, Range(0f, 1f)]
    private float jumpAuthorityAtZeroEnergy = 0.0f; // jump impossible at 0

    private CharacterMotor2D motor;
    private ICharacterIntentSource intentSource;
    private IForceBody body;
    private PlayerLadderClimber ladderClimber;

    // Jump press latch (solves Update vs FixedUpdate pulse drop)
    private bool _jumpPressedLatched;

    public void SetEnabled(bool value) => enabledFlag = value;

    void Awake()
    {
        motor = GetComponent<CharacterMotor2D>();
        body = GetComponent<IForceBody>();
        intentSource = GetComponent<ICharacterIntentSource>();
        ladderClimber = GetComponent<PlayerLadderClimber>();

        if (body == null)
        {
            Debug.LogError("CharacterMoveForce requires IForceBody (use ForceBody2D).");
            enabled = false;
            return;
        }
        if (intentSource == null)
        {
            Debug.LogError("CharacterMoveForce requires an ICharacterIntentSource (e.g., LocalCharacterIntentSource).");
            enabled = false;
            return;
        }

        if (attributes == null)
            attributes = GetComponent<PlayerAttributeState>();
    }

    public void ApplyForces(IForceBody body)
    {
        if (!enabledFlag) return;

        if (ladderClimber != null && ladderClimber.IsClimbing)
        {
            _jumpPressedLatched = false;

            if (intentSource is LocalCharacterIntentSource local)
                local.ConsumeJumpPressed();

            motor.UpdateGrounded();
            motor.TickTimers(Time.fixedDeltaTime, jumpPressed: false);
            return;
        }

        float dt = Time.fixedDeltaTime;
        var intent = intentSource.Current;

        // Grounded first (used for jump latch rules)
        motor.UpdateGrounded();

        // Compute "uprightness" angle once
        float absFromUpright = Mathf.Abs(Mathf.DeltaAngle(body.rb.rotation, 0f));
        bool jumpAngleOk = absFromUpright <= maxJumpAngleDeg;

        if (intent.JumpPressed && debugJumpDecisions)
        {
            motor.DebugLogJumpCheck(
                "CharacterMoveForce.BeforeLatch",
                jumpPressed: true,
                decision:
                    $"rawPress. angle={absFromUpright:F1}/{maxJumpAngleDeg:F1}, " +
                    $"jumpAngleOk={jumpAngleOk}, latchedBefore={_jumpPressedLatched}");
        }

        // Do not allow jump to be queued while airborne.
        // This keeps your existing behavior, but now logs why it happened.
        if (!motor.IsGrounded)
        {
            if (_jumpPressedLatched && debugJumpDecisions)
            {
                motor.DebugLogJumpCheck(
                    "CharacterMoveForce.ClearLatch",
                    jumpPressed: true,
                    decision: "Cleared latch because motor.IsGrounded=false.");
            }

            _jumpPressedLatched = false;
        }

        // Only latch jump when:
        // - grounded (no in-air queueing)
        // - within allowed jump angle
        if (intent.JumpPressed && motor.IsGrounded && jumpAngleOk)
        {
            _jumpPressedLatched = true;

            if (debugJumpDecisions)
            {
                motor.DebugLogJumpCheck(
                    "CharacterMoveForce.Latch",
                    jumpPressed: true,
                    decision: "Latched jump.");
            }
        }

        // If jump was pressed but not eligible, consume it so it can't linger (local input)
        if (intent.JumpPressed && (!motor.IsGrounded || !jumpAngleOk))
        {
            if (debugJumpDecisions)
            {
                string reason = !motor.IsGrounded
                    ? "Jump press blocked/consumed: not grounded."
                    : $"Jump press blocked/consumed: angle too steep ({absFromUpright:F1} > {maxJumpAngleDeg:F1}).";

                motor.DebugLogJumpCheck(
                    "CharacterMoveForce.BlockPress",
                    jumpPressed: true,
                    decision: reason);
            }

            if (intentSource is LocalCharacterIntentSource localBadPress)
                localBadPress.ConsumeJumpPressed();
        }

        motor.TickTimers(dt, _jumpPressedLatched);

        var ee = GetComponentInChildren<PlayerExertionEnergyState>();

        // --- Jump (grounded-only + angle-gated + energy-gated) ---
        if (_jumpPressedLatched)
        {
            if (debugJumpDecisions)
            {
                motor.DebugLogJumpCheck(
                    "CharacterMoveForce.ExecuteGate",
                    jumpPressed: true,
                    decision:
                        $"latched=true, grounded={motor.IsGrounded}, jumpAngleOk={jumpAngleOk}, " +
                        $"energy={(ee != null ? ee.Energy01.ToString("F3") : "none")}");
            }

            if (!motor.IsGrounded)
            {
                if (debugJumpDecisions)
                {
                    motor.DebugLogJumpCheck(
                        "CharacterMoveForce.ExecuteBlocked",
                        jumpPressed: true,
                        decision: "Latched jump blocked at execution: not grounded.");
                }

                _jumpPressedLatched = false;
            }
            else if (!jumpAngleOk)
            {
                if (debugJumpDecisions)
                {
                    motor.DebugLogJumpCheck(
                        "CharacterMoveForce.ExecuteBlocked",
                        jumpPressed: true,
                        decision: $"Latched jump blocked at execution: angle too steep ({absFromUpright:F1}).");
                }

                _jumpPressedLatched = false;
            }
            else if (ee != null && ee.Energy01 <= 0.0001f)
            {
                if (debugJumpDecisions)
                {
                    motor.DebugLogJumpCheck(
                        "CharacterMoveForce.ExecuteBlocked",
                        jumpPressed: true,
                        decision: "Latched jump blocked at execution: zero energy.");
                }

                _jumpPressedLatched = false;

                if (intentSource is LocalCharacterIntentSource localNoJump)
                    localNoJump.ConsumeJumpPressed();
            }
            else
            {
                _jumpPressedLatched = false;

                if (intentSource is LocalCharacterIntentSource local)
                    local.ConsumeJumpPressed();

                // Scale jump force with energy
                float jumpAuth = EvaluateJumpAuthority(ee);

                var v = body.rb.linearVelocity;
                if (v.y < 0f) v.y = 0f;
                body.rb.linearVelocity = v;

                float jumpImpulse = attributes != null
                    ? attributes.GetFloat(PlayerAttributeId.JumpImpulse, motor.jumpImpulse)
                    : motor.jumpImpulse;

                body.AddForce(Vector2.up * ((jumpImpulse * jumpAuth) * body.Mass / dt));

                if (debugJumpDecisions)
                {
                    motor.DebugLogJumpCheck(
                        "CharacterMoveForce.EXECUTED",
                        jumpPressed: true,
                        decision:
                            $"Jump executed. jumpImpulse={motor.jumpImpulse:F2}, jumpAuth={jumpAuth:F2}, " +
                            $"mass={body.Mass:F2}, dt={dt:F4}");
                }

                // Exertion impulse from jump
                if (ee != null)
                    ee.AddExertionImpulse01(jumpExertionImpulse01);

                motor.TickTimers(0f, jumpPressed: false);
            }
        }

        // -------------------------------------------------
        // Horizontal movement (scaled by "uprightness")
        // -------------------------------------------------
        float moveScale = ComputeMoveScale(body.rb.rotation);

        float targetX = intent.MoveX;

        // Scale both speed cap and force so it *feels* like crawling, not ice-skating.
        float walkMaxSpeed = attributes != null
            ? attributes.GetFloat(PlayerAttributeId.WalkMaxSpeed, motor.maxSpeed)
            : motor.maxSpeed;

        float walkMoveForce = attributes != null
            ? attributes.GetFloat(PlayerAttributeId.WalkMoveForce, motor.moveForce)
            : motor.moveForce;

        float scaledMaxSpeed = walkMaxSpeed * moveScale;
        float scaledMoveForce = walkMoveForce * moveScale;

        var sub = GetComponent<PlayerSubmersionState>();
        if (sub != null && sub.InWater && !sub.SubmergedEnoughToSwim)
        {
            // As you approach swim threshold, you slow down.
            // 0..1 => 1..0.4 (tune)
            float wadeSlow = Mathf.Lerp(1f, wadeMinMoveMultiplier, sub.Wading01);

            scaledMaxSpeed *= wadeSlow;
            scaledMoveForce *= wadeSlow;
        }

        float moveAuth = (ee != null) ? ee.MoveAuthority : 1f;
        float sprintAuth = (ee != null) ? ee.SprintAuthority : 1f;

        // Sprint is fully disabled at 0 energy.
        bool canSprint = (ee == null) ? true : ee.CanSprint;

        // Only sprint if requested AND allowed.
        bool wantsSprint = intent.SprintHeld && canSprint;

        if (wantsSprint)
        {
            // Authority scales "how much sprint you actually get"
            float sprintLerp = sprintAuth; // 1 = full sprint, 0.3 = weak sprint
            float runSpeedMultiplier = attributes != null
                ? attributes.GetFloat(PlayerAttributeId.RunSpeedMultiplier, sprintSpeedMultiplier)
                : sprintSpeedMultiplier;

            float runForceMultiplier = attributes != null
                ? attributes.GetFloat(PlayerAttributeId.RunForceMultiplier, sprintForceMultiplier)
                : sprintForceMultiplier;

            scaledMaxSpeed *= Mathf.Lerp(1f, runSpeedMultiplier, sprintLerp);
            scaledMoveForce *= Mathf.Lerp(1f, runForceMultiplier, sprintLerp);
        }
        else
        {
            // Move authority always applies when not sprinting (exhaustion sluggishness)
            scaledMaxSpeed *= moveAuth;
            scaledMoveForce *= moveAuth;
        }

        if (moveScale > 0.0001f)
        {
            float vx = body.rb.linearVelocity.x;

            // Same logic, but using the scaled speed limit
            bool underSpeedLimit = Mathf.Abs(vx) < scaledMaxSpeed || Mathf.Sign(targetX) != Mathf.Sign(vx);

            if (Mathf.Abs(targetX) > 0.01f && underSpeedLimit)
            {
                body.AddForce(Vector2.right * (targetX * scaledMoveForce));
            }
        }
    }

    private float ComputeMoveScale(float currentAngleDeg)
    {
        // 0..180 (0 = upright, 90 = sideways, 180 = upside down)
        float absFromUpright = Mathf.Abs(Mathf.DeltaAngle(currentAngleDeg, 0f));

        // Fully disabled when too inverted
        if (absFromUpright >= disabledAngleDeg)
            return 0f;

        // Between sideways and disabled: fade from crawl to 0 (prevents a hard cutoff at 100)
        if (absFromUpright >= crawlAngleDeg)
        {
            float t = Mathf.InverseLerp(crawlAngleDeg, disabledAngleDeg, absFromUpright); // 0..1
            return Mathf.Lerp(crawlMoveMultiplier, 0f, t);
        }

        // 0..crawlAngle: fade from 1 to crawl
        {
            float t = Mathf.InverseLerp(0f, crawlAngleDeg, absFromUpright); // 0..1
            return Mathf.Lerp(1f, crawlMoveMultiplier, t);
        }
    }

    private float EvaluateJumpAuthority(PlayerExertionEnergyState ee)
    {
        if (ee == null) return 1f;

        float e = ee.Energy01; // works even with discrete energy
        if (e <= 0.0001f) return 0f;

        // Above low threshold: full jump
        if (e >= ee.lowEnergyThreshold) return 1f;

        // 0..lowThreshold mapped to [jumpAuthorityAtZeroEnergy..jumpAuthorityAtLowEnergy]
        float t = (ee.lowEnergyThreshold <= 0.0001f) ? 1f : (e / ee.lowEnergyThreshold);
        return Mathf.Lerp(jumpAuthorityAtZeroEnergy, jumpAuthorityAtLowEnergy, Mathf.Clamp01(t));
    }
}