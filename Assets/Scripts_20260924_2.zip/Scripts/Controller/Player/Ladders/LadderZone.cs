using UnityEngine;

[DisallowMultipleComponent]
[RequireComponent(typeof(Collider2D))]
public sealed class LadderZone : MonoBehaviour, IInteractable, IInteractionPointProvider
{
    public enum BoatAccessMode
    {
        // If the ladder belongs to a boat, classify it from the BoatBoardedVolume:
        // climb center inside = interior, outside = exterior.
        Auto = 0,
        InteriorOnly = 1,
        ExteriorOnly = 2,
        Any = 3
    }

    [Header("Climb")]
    [SerializeField] private float climbSpeed = 3.25f;
    [SerializeField] private float snapToCenterSpeed = 18f;
    [SerializeField] private bool requireInteractToClimb = false;
    [SerializeField] private bool allowImplicitDownClimb = true;

    [Header("Exit")]
    [SerializeField] private bool allowTopExit = true;
    [SerializeField] private bool allowBottomExit = true;
    [SerializeField] private float topExitMargin = 0.15f;
    [SerializeField] private float bottomExitMargin = 0.15f;
    [SerializeField] private Transform topExitPoint;
    [SerializeField] private Transform bottomExitPoint;

    [Header("Interaction")]
    [SerializeField] private int interactionPriority = 25;
    [SerializeField] private float maxInteractDistance = 1.5f;

    [Header("Centering")]
    [SerializeField] private Transform climbCenter;

    [Header("Boat Access")]
    [Tooltip("Auto classifies a boat ladder by whether its climb center is inside the BoatBoardedVolume. " +
             "Use InteriorOnly/ExteriorOnly to override unusual ladder geometry.")]
    [SerializeField] private BoatAccessMode boatAccessMode = BoatAccessMode.Auto;

    [Header("Debug")]
    [SerializeField] private bool debugLogs = false;

    private Collider2D _collider;

    public int InteractionPriority => interactionPriority;
    public float ClimbSpeed => climbSpeed;
    public float SnapToCenterSpeed => snapToCenterSpeed;
    public bool RequireInteractToClimb => requireInteractToClimb;
    public bool AllowImplicitDownClimb => allowImplicitDownClimb;
    public bool AllowTopExit => allowTopExit;
    public bool AllowBottomExit => allowBottomExit;
    public float TopExitMargin => Mathf.Max(0f, topExitMargin);
    public float BottomExitMargin => Mathf.Max(0f, bottomExitMargin);
    public Transform TopExitPoint => topExitPoint;
    public Transform BottomExitPoint => bottomExitPoint;
    public Transform ClimbCenter => climbCenter != null ? climbCenter : transform;
    public BoatAccessMode AccessMode => boatAccessMode;

    private void Awake()
    {
        _collider = GetComponent<Collider2D>();
        if (_collider != null)
            _collider.isTrigger = true;
    }

    public Vector2 GetClosestInteractionPoint(Vector2 fromWorldPoint)
    {
        if (_collider == null)
            _collider = GetComponent<Collider2D>();

        if (_collider == null)
            return transform.position;

        return _collider.ClosestPoint(fromWorldPoint);
    }

    public bool CanInteract(in InteractContext context)
    {
        if (!requireInteractToClimb)
        {
            Log("CanInteract = false because requireInteractToClimb is false.");
            return false;
        }

        if (context.InteractorGO == null)
        {
            Log("CanInteract = false because interactor GO was null.");
            return false;
        }

        Vector2 closestPoint = GetClosestInteractionPoint(context.Origin);
        float dist = Vector2.Distance(context.Origin, closestPoint);

        if (dist > maxInteractDistance)
        {
            Log($"CanInteract = false because closest distance {dist:0.00} > max {maxInteractDistance:0.00}.");
            return false;
        }

        var climber = context.InteractorGO.GetComponentInChildren<PlayerLadderClimber>(true);
        bool can = climber != null && climber.CanBeginClimb(this);

        Log($"CanInteract evaluated. climberFound={climber != null}, closestDist={dist:0.00}, result={can}");
        return can;
    }

    public void Interact(in InteractContext context)
    {
        Log($"Interact called by '{context.InteractorGO?.name ?? "NULL"}'.");

        if (context.InteractorGO == null)
            return;

        var climber = context.InteractorGO.GetComponentInChildren<PlayerLadderClimber>(true);
        if (climber == null)
        {
            Log("Interact aborted. No PlayerLadderClimber found on interactor.");
            return;
        }

        climber.TryBeginClimb(this);
    }

    public bool TryGetWorldYBounds(out float minY, out float maxY)
    {
        minY = 0f;
        maxY = 0f;

        if (_collider == null)
            _collider = GetComponent<Collider2D>();

        if (_collider == null)
        {
            Log("TryGetWorldYBounds failed because no Collider2D was found.");
            return false;
        }

        Bounds b = _collider.bounds;
        minY = b.min.y;
        maxY = b.max.y;
        return true;
    }

    /// <summary>
    /// Returns the ladder collider's longitudinal bounds in ladder-local Y.
    /// Unlike world-space Y bounds, these remain correct when the ladder/boat rotates.
    /// </summary>
    public bool TryGetLocalClimbBounds(out float minLocalY, out float maxLocalY)
    {
        minLocalY = 0f;
        maxLocalY = 0f;

        if (_collider == null)
            _collider = GetComponent<Collider2D>();

        if (_collider == null)
        {
            Log("TryGetLocalClimbBounds failed because no Collider2D was found.");
            return false;
        }

        if (_collider is BoxCollider2D box)
        {
            Vector2 half = box.size * 0.5f;
            Vector2 offset = box.offset;

            Vector2[] localCorners =
            {
                offset + new Vector2(-half.x, -half.y),
                offset + new Vector2(-half.x,  half.y),
                offset + new Vector2( half.x,  half.y),
                offset + new Vector2( half.x, -half.y)
            };

            minLocalY = float.PositiveInfinity;
            maxLocalY = float.NegativeInfinity;

            for (int i = 0; i < localCorners.Length; i++)
            {
                Vector3 world =
                    box.transform.TransformPoint(
                        localCorners[i]);

                float ladderLocalY =
                    transform.InverseTransformPoint(
                        world).y;

                minLocalY =
                    Mathf.Min(
                        minLocalY,
                        ladderLocalY);

                maxLocalY =
                    Mathf.Max(
                        maxLocalY,
                        ladderLocalY);
            }

            return
                !float.IsInfinity(minLocalY) &&
                !float.IsInfinity(maxLocalY) &&
                maxLocalY >= minLocalY;
        }

        // Generic fallback for unusual ladder collider types. Collider2D.bounds is
        // world-axis-aligned, so this can be slightly conservative on rotated shapes,
        // but BoxCollider2D is the authored ladder path and remains exact above.
        Bounds bounds = _collider.bounds;

        Vector3[] worldCorners =
        {
            new Vector3(bounds.min.x, bounds.min.y, transform.position.z),
            new Vector3(bounds.min.x, bounds.max.y, transform.position.z),
            new Vector3(bounds.max.x, bounds.max.y, transform.position.z),
            new Vector3(bounds.max.x, bounds.min.y, transform.position.z)
        };

        minLocalY = float.PositiveInfinity;
        maxLocalY = float.NegativeInfinity;

        for (int i = 0; i < worldCorners.Length; i++)
        {
            float ladderLocalY =
                transform.InverseTransformPoint(
                    worldCorners[i]).y;

            minLocalY =
                Mathf.Min(
                    minLocalY,
                    ladderLocalY);

            maxLocalY =
                Mathf.Max(
                    maxLocalY,
                    ladderLocalY);
        }

        return
            !float.IsInfinity(minLocalY) &&
            !float.IsInfinity(maxLocalY) &&
            maxLocalY >= minLocalY;
    }

    private void Log(string message)
    {
        if (!debugLogs)
            return;

        Debug.Log($"[LadderZone:{name}] {message}", this);
    }

#if UNITY_EDITOR
    private void OnValidate()
    {
        Collider2D col = GetComponent<Collider2D>();
        if (col != null)
            col.isTrigger = true;
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = new Color(0.3f, 0.85f, 1f, 0.9f);

        var c = ClimbCenter;
        Gizmos.DrawWireSphere(c.position, 0.08f);

        if (TryGetLocalClimbBounds(out float minLocalY, out float maxLocalY))
        {
            Vector3 centerLocal =
                transform.InverseTransformPoint(
                    c.position);

            Vector3 a =
                transform.TransformPoint(
                    new Vector3(
                        centerLocal.x,
                        minLocalY,
                        centerLocal.z));

            Vector3 b =
                transform.TransformPoint(
                    new Vector3(
                        centerLocal.x,
                        maxLocalY,
                        centerLocal.z));

            Gizmos.DrawLine(a, b);
        }

        if (topExitPoint != null)
        {
            Gizmos.color = Color.green;
            Gizmos.DrawWireSphere(topExitPoint.position, 0.08f);
        }

        if (bottomExitPoint != null)
        {
            Gizmos.color = Color.yellow;
            Gizmos.DrawWireSphere(bottomExitPoint.position, 0.08f);
        }
    }
#endif
}