﻿using UnityEngine;
using UnityEngine.Serialization;

[DisallowMultipleComponent]
public sealed class HardpointInteractable :
    MonoBehaviour,
    IInteractable,
    IPickupInteractable,
    IInteractPromptProvider,
    IPickupPromptProvider,
    IToggleInteractable,
    ILinkInteractable,
    IInteractionLabelProvider,
    IInteractionPromptDisplayPolicyProvider,
    IInteractionColliderScope
{
    [Header("Refs")]
    [SerializeField] private Hardpoint hardpoint;
    [SerializeField] private Transform promptAnchor;

    [Header("Interaction")]
    [SerializeField] private int interactionPriority = 20;
    [SerializeField] private int pickupPriority = 20;
    [SerializeField] private float maxDistance = 1.75f;
    [Tooltip("If true, the hardpoint/module hover label is hidden unless the player is in valid access context and action range.")]
    [SerializeField] private bool hideHoverLabelWhenNotActionable = true;

    [Header("Interaction Geometry")]
    [Tooltip(
        "Legacy / empty-hardpoint interaction collider(s). Existing hardpoints with " +
        "their collider on this same GameObject are discovered automatically.")]
    [SerializeField] private Collider2D[] fallbackInteractionColliders;

    [Header("Boat Access")]
    [Tooltip("If true, hardpoints/modules that belong to a Boat can only be used by players boarded on that same boat.")]
    [SerializeField] private bool requireMatchingBoatBoardingContext = true;

    [Tooltip("If true, hardpoints not under a Boat remain usable. This keeps future dock/ruin/world modules possible until they get their own access context.")]
    [SerializeField] private bool allowAccessWhenNotPartOfBoat = true;

    [Tooltip("Marks this hardpoint/module as exterior. Exterior modules are serviced while unboarded, follow exterior visibility, and do not consume internal cargo/module footprint space.")]
    [FormerlySerializedAs("allowExternalAccessWhenUnboarded")]
    [SerializeField] private bool exteriorModule = false;

    [Header("Removal")]
    [SerializeField] private PickupInteractionMode pickupMode = PickupInteractionMode.Hold;
    [SerializeField] private float pickupHoldDuration = 0.5f;

    public int InteractionPriority => interactionPriority;
    public int PickupPriority => pickupPriority;
    public PickupInteractionMode PickupMode => pickupMode;
    public float PickupHoldDuration => pickupHoldDuration;
    public bool ExteriorModule => exteriorModule;
    public Hardpoint TargetHardpoint => hardpoint;

    private Boat _cachedBoat;
    private InstalledModule _cachedInteractionModule;
    private InstalledModuleInteractionZone _cachedInteractionZone;

    private void Reset()
    {
        if (hardpoint == null)
            hardpoint = GetComponent<Hardpoint>();

        if (promptAnchor == null)
            promptAnchor = transform;

        CacheFallbackInteractionColliders();
        InvalidateInstalledInteractionZoneCache();
        CacheBoat();
    }


    private void Awake()
    {
        if (hardpoint == null)
            hardpoint = GetComponent<Hardpoint>();

        if (promptAnchor == null)
            promptAnchor = transform;

        CacheFallbackInteractionColliders();
        InvalidateInstalledInteractionZoneCache();
        CacheBoat();
    }


    public bool CanInteract(in InteractContext context)
    {
        if (hardpoint == null)
            return false;

        if (!IsInRange(context))
            return false;

        if (!CanAccessHardpointByContext(context))
            return false;

        if (hardpoint.HasInstalledModule)
            return true;

        return TryFindCompatiblePlayerModule(
            context,
            out _,
            out _,
            out _,
            out _);
    }

    public void Interact(in InteractContext context)
    {
        if (hardpoint == null || !IsInRange(context))
            return;

        if (!CanAccessHardpointByContext(context))
            return;

        if (!hardpoint.HasInstalledModule)
        {
            TryInstallFromPlayerInventory(context);
            return;
        }

        OpenInstalledModuleUI(context);
    }

    public bool CanPickup(in InteractContext context)
    {
        if (hardpoint == null)
            return false;

        if (!hardpoint.HasInstalledModule)
            return false;

        if (!IsInRange(context))
            return false;

        if (!CanAccessHardpointByContext(context))
            return false;

        return true;
    }

    public void Pickup(in InteractContext context)
    {
        if (hardpoint == null || !hardpoint.HasInstalledModule || !IsInRange(context))
            return;

        if (!CanAccessHardpointByContext(context))
            return;

        if (TryGetRemovalBlockingTetherDeployment(out TetherDeploymentModule blockingDeployment))
        {
            Debug.Log(
                $"[HardpointInteractable] Cannot remove module while tether payload is deployed " +
                $"from '{blockingDeployment.name}'. Stow the payload first.",
                this);

            return;
        }

        if (InstalledModuleHasContents())
        {
            Debug.Log("[HardpointInteractable] Cannot remove module while it contains items.", this);
            return;
        }

        PlayerInventory inventory = context.InteractorGO != null
            ? context.InteractorGO.GetComponentInChildren<PlayerInventory>()
            : null;

        if (inventory == null)
            return;

        if (!hardpoint.TryRemove(out ModuleDefinition removedDefinition))
            return;

        ItemDefinition itemDef = removedDefinition != null ? removedDefinition.ItemDefinition : null;
        if (itemDef == null)
        {
            Debug.LogWarning("[HardpointInteractable] Removed module had no linked ItemDefinition.", this);
            return;
        }

        ItemInstance returnedItem = ItemInstance.Create(itemDef, 1);

        if (!inventory.TryAutoInsert(returnedItem, out ItemInstance remainder))
        {
            hardpoint.TryInstall(removedDefinition, out _);
            return;
        }

        if (remainder != null && !remainder.IsDepleted())
        {
            hardpoint.TryInstall(removedDefinition, out _);
            return;
        }

        inventory.NotifyChanged();
    }

    public bool CanToggle(in InteractContext context)
    {
        if (hardpoint == null || !hardpoint.HasInstalledModule || !IsInRange(context))
            return false;

        if (!CanAccessHardpointByContext(context))
            return false;

        return TryGetInstalledToggleable(out _);
    }

    public void Toggle(in InteractContext context)
    {
        if (!CanAccessHardpointByContext(context))
            return;

        if (!TryGetInstalledToggleable(out IModuleToggleable toggleable))
            return;

        toggleable.Toggle();
    }

    public bool CanLink(
        in InteractContext context)
    {
        if (hardpoint == null ||
            !IsInRange(context) ||
            !CanAccessHardpointByContext(context))
        {
            return false;
        }

        HelmLinkSession existing =
            HelmLinkSession.Get(
                context.InteractorGO);

        // Let the player cancel a selected Helm even if its installed module
        // disappeared after selection.
        if (existing != null &&
            existing.PendingHelmHardpoint == hardpoint)
        {
            return true;
        }

        if (!hardpoint.HasInstalledModule ||
            hardpoint.InstalledModule == null)
        {
            return false;
        }

        return hardpoint.InstalledModule
            .GetComponent<HelmModule>() != null;
    }

    public string GetLinkPromptVerb(
        in InteractContext context)
    {
        HelmLinkSession session =
            HelmLinkSession.Get(
                context.InteractorGO);

        if (session != null &&
            session.PendingHelmHardpoint == hardpoint)
        {
            return "Cancel Helm Link";
        }

        return "Select Helm for Linking";
    }

    public void Link(
        in InteractContext context)
    {
        if (!CanLink(context))
            return;

        HelmLinkSession session =
            HelmLinkSession.GetOrCreate(
                context.InteractorGO);

        if (session == null)
            return;

        if (session.PendingHelmHardpoint == hardpoint)
        {
            session.Cancel();

            Debug.Log(
                $"[HelmLink] Cancelled helm link selection for '{hardpoint.HardpointId}'.",
                this);

            return;
        }

        session.Begin(
            hardpoint);

        Debug.Log(
            $"[HelmLink] Selected helm hardpoint '{hardpoint.HardpointId}'. " +
            "Hover a Pilot Chair and press L to complete the link.",
            this);
    }

    public string GetPromptVerb(in InteractContext context)
    {
        if (hardpoint == null)
            return "Use Hardpoint";

        if (!CanAccessHardpointByContext(context))
            return GetAccessDeniedPrompt(context);

        if (!hardpoint.HasInstalledModule)
        {
            if (TryFindCompatiblePlayerModule(
                    context,
                    out _,
                    out ItemInstance moduleItem,
                    out _,
                    out _)
                && moduleItem?.Definition?.ModuleDefinition != null)
            {
                return $"Install {moduleItem.Definition.DisplayName}";
            }

            return "Install Module";
        }

        if (hardpoint.InstalledModule != null &&
            hardpoint.InstalledModule.GetComponent<HelmModule>() != null)
        {
            return "Open Helm";
        }

        if (hardpoint.InstalledModule != null &&
            hardpoint.InstalledModule.GetComponent<WinchModule>() != null)
        {
            return "Open Winch";
        }

        return "Open Module";
    }

    public string GetPickupPromptVerb(in InteractContext context)
    {
        if (!CanAccessHardpointByContext(context))
            return GetAccessDeniedPrompt(context);

        if (hardpoint != null && hardpoint.HasInstalledModule)
        {
            if (TryGetRemovalBlockingTetherDeployment(out _))
                return "Remove Module (Stow Payload First)";

            if (InstalledModuleHasContents())
                return "Remove Module (Empty First)";

            return "Remove Module";
        }

        return "Pick Up";
    }

    public Transform GetPromptAnchor()
    {
        InstalledModuleInteractionZone zone =
            ResolveInstalledInteractionZone();

        if (zone != null &&
            zone.PromptAnchor != null)
        {
            return zone.PromptAnchor;
        }

        return
            promptAnchor != null
                ? promptAnchor
                : transform;
    }


    public EngineModule GetInstalledEngine()
    {
        if (hardpoint == null || !hardpoint.HasInstalledModule || hardpoint.InstalledModule == null)
            return null;

        return hardpoint.InstalledModule.GetComponent<EngineModule>();
    }

    private bool TryGetInstalledToggleable(out IModuleToggleable toggleable)
    {
        toggleable = null;

        if (hardpoint == null || !hardpoint.HasInstalledModule || hardpoint.InstalledModule == null)
            return false;

        MonoBehaviour[] behaviours = hardpoint.InstalledModule.GetComponents<MonoBehaviour>();

        for (int i = 0; i < behaviours.Length; i++)
        {
            if (behaviours[i] is IModuleToggleable candidate)
            {
                toggleable = candidate;
                return true;
            }
        }

        return false;
    }

    public bool TryGetInstalledToggleState(out bool isOn, out string label)
    {
        isOn = false;
        label = "Module";

        if (hardpoint == null || !hardpoint.HasInstalledModule || hardpoint.InstalledModule == null)
            return false;

        InstalledModule installed = hardpoint.InstalledModule;
        ModuleDefinition def = installed.Definition;

        label = def != null ? def.DisplayName : "Module";

        if (installed.TryGetComponent(out EngineModule engine))
        {
            isOn = engine.IsOn;
            return true;
        }

        if (installed.TryGetComponent(out GeneratorModule generator))
        {
            isOn = generator.IsOn;
            return true;
        }

        if (installed.TryGetComponent(out PumpModule pump))
        {
            isOn = pump.IsOn;
            return true;
        }

        if (installed.TryGetComponent(out TurretModule turret))
        {
            isOn = turret.IsOn;
            return true;
        }

        return false;
    }

    private void TryInstallFromPlayerInventory(in InteractContext context)
    {
        if (!TryFindCompatiblePlayerModule(
                context,
                out PlayerInventory inventory,
                out ItemInstance moduleItem,
                out BottomBarSlotType sourceSlotType,
                out bool sourceIsEquipment))
        {
            return;
        }

        if (moduleItem == null || moduleItem.Definition == null)
            return;

        ModuleDefinition moduleDefinition = moduleItem.Definition.ModuleDefinition;
        if (moduleDefinition == null)
            return;

        if (!hardpoint.TryInstall(moduleDefinition, out _))
            return;

        bool removedFromSource = false;

        if (sourceIsEquipment)
        {
            PlayerEquipment equipment = context.InteractorGO != null
                ? context.InteractorGO.GetComponentInChildren<PlayerEquipment>(true)
                : null;

            if (equipment != null)
            {
                ItemInstance equipped = equipment.Get(sourceSlotType);
                if (ReferenceEquals(equipped, moduleItem))
                {
                    equipment.Remove(sourceSlotType);
                    removedFromSource = true;
                }
            }
        }
        else
        {
            int hotbarIndex = PlayerInventory.SlotTypeToHotbarIndex(sourceSlotType);
            InventorySlot sourceSlot = inventory.GetSlot(hotbarIndex);

            if (sourceSlot != null && ReferenceEquals(sourceSlot.Instance, moduleItem))
            {
                sourceSlot.Clear();
                removedFromSource = true;
            }
        }

        if (!removedFromSource)
        {
            hardpoint.TryRemove(out _);
            Debug.LogWarning(
                "[HardpointInteractable] Installed module but failed to remove source item. Rolled back install.",
                this);
            return;
        }

        inventory.NotifyChanged();
    }

    private void OpenInstalledModuleUI(in InteractContext context)
    {
        if (hardpoint != null &&
            hardpoint.HasInstalledModule &&
            hardpoint.InstalledModule != null &&
            hardpoint.InstalledModule.GetComponent<HelmModule>() != null)
        {
            HelmOverlayRunner helmRunner =
                FindFirstObjectByType<HelmOverlayRunner>();

            if (helmRunner == null)
            {
                Debug.LogWarning(
                    "[HardpointInteractable] No HelmOverlayRunner found.",
                    this);
                return;
            }

            helmRunner.OpenForHardpoint(
                hardpoint);

            return;
        }

        if (hardpoint != null &&
            hardpoint.HasInstalledModule &&
            hardpoint.InstalledModule != null &&
            hardpoint.InstalledModule.GetComponent<WinchModule>() != null)
        {
            WinchOverlayRunner winchRunner =
                FindFirstObjectByType<WinchOverlayRunner>();

            if (winchRunner == null)
            {
                Debug.LogWarning(
                    "[HardpointInteractable] No WinchOverlayRunner found.",
                    this);

                return;
            }

            winchRunner.OpenForHardpoint(
                hardpoint,
                context.InteractorGO);

            return;
        }

        if (hardpoint != null &&
            hardpoint.HasInstalledModule &&
            hardpoint.InstalledModule != null &&
            hardpoint.InstalledModule.TryGetComponent(out StorageModule storage))
        {
            storage.EnsureContainer();

            ExternalContainerOverlayUI overlay = FindFirstObjectByType<ExternalContainerOverlayUI>();
            if (overlay == null)
            {
                Debug.LogWarning("[HardpointInteractable] No ExternalContainerOverlayUI found.", this);
                return;
            }

            ModuleDefinition def = hardpoint.InstalledModule.Definition;
            string title = def != null ? def.DisplayName : "Storage";

            if (overlay.IsOpen && overlay.CurrentStorageModule == storage)
            {
                overlay.Close();
                return;
            }

            overlay.OpenStorage(title, storage, transform, 2.25f);
            return;
        }

        ModuleOverlayRunner runner = FindFirstObjectByType<ModuleOverlayRunner>();
        if (runner == null)
        {
            Debug.LogWarning("[HardpointInteractable] No ModuleOverlayRunner found.", this);
            return;
        }

        runner.OpenForHardpoint(hardpoint);
    }

    private bool IsInRange(
        in InteractContext context)
    {
        InstalledModuleInteractionZone zone =
            ResolveInstalledInteractionZone();

        if (zone != null &&
            zone.HasInteractionColliders)
        {
            return
                zone.GetDistanceFrom(
                    context.Origin) <=
                maxDistance;
        }

        return
            GetFallbackInteractionDistance(
                context.Origin) <=
            maxDistance;
    }


    /// <summary>
    /// Source-collider scope for this hardpoint interaction owner.
    ///
    /// Empty hardpoint or legacy installed module:
    ///     use the hardpoint's own fallback collider(s).
    ///
    /// Installed module with an authored InstalledModuleInteractionZone:
    ///     only that module's authored collider(s) may resolve this owner.
    /// </summary>
    public bool AllowsInteractionCollider(
        Collider2D sourceCollider)
    {
        if (sourceCollider == null ||
            hardpoint == null)
        {
            return false;
        }

        InstalledModuleInteractionZone zone =
            ResolveInstalledInteractionZone();

        if (zone != null &&
            zone.HasInteractionColliders)
        {
            return
                zone.Contains(
                    sourceCollider);
        }

        return
            IsFallbackInteractionCollider(
                sourceCollider);
    }

    private InstalledModuleInteractionZone ResolveInstalledInteractionZone()
    {
        InstalledModule installed =
            hardpoint != null &&
            hardpoint.HasInstalledModule
                ? hardpoint.InstalledModule
                : null;

        if (installed != _cachedInteractionModule)
        {
            _cachedInteractionModule =
                installed;

            _cachedInteractionZone =
                installed != null
                    ? installed.GetComponentInChildren<InstalledModuleInteractionZone>(
                        true)
                    : null;
        }
        else if (installed != null &&
                 _cachedInteractionZone == null)
        {
            // Migration-friendly retry. If editor/runtime tooling adds a zone after
            // this module was already installed, it can become active without a
            // separate hardpoint refresh API.
            _cachedInteractionZone =
                installed.GetComponentInChildren<InstalledModuleInteractionZone>(
                    true);
        }

        return
            _cachedInteractionZone;
    }

    private void InvalidateInstalledInteractionZoneCache()
    {
        _cachedInteractionModule =
            null;

        _cachedInteractionZone =
            null;
    }

    private void CacheFallbackInteractionColliders()
    {
        if (fallbackInteractionColliders != null &&
            fallbackInteractionColliders.Length > 0)
        {
            return;
        }

        // Preserve the existing common setup with zero prefab edits:
        // HardpointInteractable + its BoxCollider2D on the same object.
        fallbackInteractionColliders =
            GetComponents<Collider2D>();
    }

    private bool IsFallbackInteractionCollider(
        Collider2D sourceCollider)
    {
        if (sourceCollider == null)
            return false;

        CacheFallbackInteractionColliders();

        if (fallbackInteractionColliders != null)
        {
            for (int i = 0;
                 i < fallbackInteractionColliders.Length;
                 i++)
            {
                if (ReferenceEquals(
                        fallbackInteractionColliders[i],
                        sourceCollider))
                {
                    return true;
                }
            }
        }

        // Compatibility for an older hardpoint whose interaction collider was
        // authored on a child. Never reinterpret an installed module's arbitrary
        // structural/physics collider as the fallback interaction surface.
        Transform hardpointRoot =
            hardpoint != null
                ? hardpoint.transform
                : transform;

        Transform installedRoot =
            hardpoint != null &&
            hardpoint.InstalledModule != null
                ? hardpoint.InstalledModule.transform
                : null;

        Transform sourceTransform =
            sourceCollider.transform;

        bool belongsToHardpoint =
            sourceTransform == hardpointRoot ||
            sourceTransform.IsChildOf(
                hardpointRoot);

        if (!belongsToHardpoint)
            return false;

        if (installedRoot != null &&
            (sourceTransform == installedRoot ||
             sourceTransform.IsChildOf(
                 installedRoot)))
        {
            return false;
        }

        return true;
    }

    private float GetFallbackInteractionDistance(
        Vector2 worldOrigin)
    {
        CacheFallbackInteractionColliders();

        float best =
            float.PositiveInfinity;

        if (fallbackInteractionColliders != null)
        {
            for (int i = 0;
                 i < fallbackInteractionColliders.Length;
                 i++)
            {
                Collider2D collider =
                    fallbackInteractionColliders[i];

                if (collider == null ||
                    !collider.enabled ||
                    !collider.gameObject.activeInHierarchy)
                {
                    continue;
                }

                Vector2 closest =
                    collider.ClosestPoint(
                        worldOrigin);

                float distance =
                    Vector2.Distance(
                        worldOrigin,
                        closest);

                if (distance < best)
                    best = distance;
            }
        }

        if (!float.IsPositiveInfinity(
                best))
        {
            return best;
        }

        return
            Vector2.Distance(
                worldOrigin,
                transform.position);
    }

    private bool CanAccessHardpointByContext(in InteractContext context)
    {
        if (!requireMatchingBoatBoardingContext)
            return true;

        CacheBoat();

        // Non-boat hardpoints keep their existing access behavior so future dock,
        // ruin, or world modules can define their own context later.
        if (_cachedBoat == null)
            return allowAccessWhenNotPartOfBoat;

        PlayerBoardingState boarding = FindBoardingState(context);
        if (boarding == null)
            return false;

        // Some boat hardpoints are physically serviced from outside the boat.
        // This is configured per hardpoint rather than inferred from HardpointType.
        if (exteriorModule)
            return !boarding.IsBoarded;

        return boarding.IsBoarded &&
               boarding.CurrentBoatRoot == _cachedBoat.transform;
    }

    private string GetAccessDeniedPrompt(in InteractContext context)
    {
        if (!requireMatchingBoatBoardingContext)
            return "Use Hardpoint";

        CacheBoat();

        if (_cachedBoat == null)
            return "Use Hardpoint";

        if (exteriorModule)
        {
            PlayerBoardingState boarding = FindBoardingState(context);
            if (boarding != null && boarding.IsBoarded)
                return "Access From Outside";
        }

        return "Board Boat";
    }

    private PlayerBoardingState FindBoardingState(in InteractContext context)
    {
        if (context.InteractorGO != null)
        {
            PlayerBoardingState fromGO =
                context.InteractorGO.GetComponentInParent<PlayerBoardingState>();

            if (fromGO != null)
                return fromGO;

            fromGO = context.InteractorGO.GetComponentInChildren<PlayerBoardingState>(true);

            if (fromGO != null)
                return fromGO;
        }

        if (context.InteractorTransform != null)
        {
            PlayerBoardingState fromTransform =
                context.InteractorTransform.GetComponentInParent<PlayerBoardingState>();

            if (fromTransform != null)
                return fromTransform;

            fromTransform =
                context.InteractorTransform.GetComponentInChildren<PlayerBoardingState>(true);

            if (fromTransform != null)
                return fromTransform;
        }

        return null;
    }

    private void CacheBoat()
    {
        if (_cachedBoat != null)
            return;

        if (hardpoint != null)
            _cachedBoat = hardpoint.GetComponentInParent<Boat>(true);

        if (_cachedBoat == null)
            _cachedBoat = GetComponentInParent<Boat>(true);

        if (_cachedBoat == null &&
            hardpoint != null &&
            hardpoint.HasInstalledModule &&
            hardpoint.InstalledModule != null)
        {
            _cachedBoat = hardpoint.InstalledModule.GetComponentInParent<Boat>(true);
        }

        if (_cachedBoat == null &&
            hardpoint != null &&
            hardpoint.InstalledModule != null)
        {
            InstalledModule installed = hardpoint.InstalledModule;
            if (installed.OwnerHardpoint != null)
                _cachedBoat = installed.OwnerHardpoint.GetComponentInParent<Boat>(true);
        }
    }

    private bool TryFindCompatiblePlayerModule(
        in InteractContext context,
        out PlayerInventory inventory,
        out ItemInstance sourceItem,
        out BottomBarSlotType sourceSlotType,
        out bool sourceIsEquipment)
    {
        inventory = context.InteractorGO != null
            ? context.InteractorGO.GetComponentInChildren<PlayerInventory>()
            : null;

        sourceItem = null;
        sourceSlotType = BottomBarSlotType.None;
        sourceIsEquipment = false;

        if (inventory == null || hardpoint == null)
            return false;

        PlayerEquipment equipment = context.InteractorGO != null
            ? context.InteractorGO.GetComponentInChildren<PlayerEquipment>(true)
            : null;

        if (equipment == null)
            return false;

        BottomBarSlotType selectedType = inventory.SelectedSlot;

        if (selectedType >= BottomBarSlotType.Hotbar0 &&
            selectedType <= BottomBarSlotType.Hotbar7)
        {
            InventorySlot selectedHotbar =
                inventory.GetSlot(PlayerInventory.SlotTypeToHotbarIndex(selectedType));

            if (IsCompatibleModuleItem(selectedHotbar?.Instance))
            {
                sourceItem = selectedHotbar.Instance;
                sourceSlotType = selectedType;
                sourceIsEquipment = false;
                return true;
            }
        }
        else
        {
            ItemInstance equippedItem = equipment.Get(selectedType);
            if (IsCompatibleModuleItem(equippedItem))
            {
                sourceItem = equippedItem;
                sourceSlotType = selectedType;
                sourceIsEquipment = true;
                return true;
            }
        }

        for (int i = 0; i < inventory.HotbarSlotCount; i++)
        {
            InventorySlot slot = inventory.GetSlot(i);
            if (IsCompatibleModuleItem(slot?.Instance))
            {
                sourceItem = slot.Instance;
                sourceSlotType = PlayerInventory.HotbarIndexToSlotType(i);
                sourceIsEquipment = false;
                return true;
            }
        }

        return false;
    }

    private bool IsCompatibleModuleItem(ItemInstance item)
    {
        if (item == null || item.Definition == null)
            return false;

        if (!item.Definition.IsModule)
            return false;

        ModuleDefinition moduleDefinition = item.Definition.ModuleDefinition;
        if (moduleDefinition == null)
            return false;

        return hardpoint != null && hardpoint.CanInstall(moduleDefinition);
    }

    private bool TryGetRemovalBlockingTetherDeployment(
        out TetherDeploymentModule deployment)
    {
        deployment = null;

        if (hardpoint == null ||
            !hardpoint.HasInstalledModule ||
            hardpoint.InstalledModule == null)
        {
            return false;
        }

        InstalledModule installed =
            hardpoint.InstalledModule;

        // Deployment scaffolding owns the deployed WorldItem even though its
        // StorageModule payload slot is temporarily empty.
        if (installed.TryGetComponent(
                out TetherDeploymentModule localDeployment) &&
            localDeployment != null &&
            localDeployment.HasDeployedPayload)
        {
            deployment =
                localDeployment;

            return true;
        }

        // A winch is also not removable while the deployment module it is
        // actively rigged to still has a payload hanging from the line.
        if (installed.GetComponent<WinchModule>() != null)
        {
            TetherWinchLink link =
                hardpoint.GetComponent<TetherWinchLink>();

            if (link != null &&
                link.TryGetDeploymentModule(
                    out TetherDeploymentModule linkedDeployment) &&
                linkedDeployment != null &&
                linkedDeployment.HasDeployedPayload)
            {
                deployment =
                    linkedDeployment;

                return true;
            }
        }

        return false;
    }

    private bool InstalledModuleHasContents()
    {
        if (hardpoint == null || !hardpoint.HasInstalledModule || hardpoint.InstalledModule == null)
            return false;

        InstalledModule installed = hardpoint.InstalledModule;

        if (installed.TryGetComponent(out EngineModule engine))
            return ContainerHasContents(engine.FuelContainerItem);

        if (installed.TryGetComponent(out GeneratorModule generator))
            return ContainerHasContents(generator.FuelContainerItem);

        if (installed.TryGetComponent(out StorageModule storage))
            return storage.HasAnyContents();

        // Later:
        // if (installed.TryGetComponent(out AmmoModule ammo)) ...

        return false;
    }

    private static bool ContainerHasContents(ItemInstance container)
    {
        if (container == null || !container.IsContainer || container.ContainerState == null)
            return false;

        ItemContainerState state = container.ContainerState;

        for (int i = 0; i < state.SlotCount; i++)
        {
            InventorySlot slot = state.GetSlot(i);
            if (slot != null && !slot.IsEmpty && slot.Instance != null)
                return true;
        }

        return false;
    }

    public string GetInteractionLabel(in InteractContext context)
    {
        if (hardpoint == null)
            return "Hardpoint";

        if (hardpoint.HasInstalledModule && hardpoint.InstalledModule != null)
        {
            ModuleDefinition def = hardpoint.InstalledModule.Definition;
            if (def != null && !string.IsNullOrWhiteSpace(def.DisplayName))
                return def.DisplayName;

            return "Installed Module";
        }

        return "Empty Hardpoint";
    }

    public bool ShouldShowHoverLabel(in InteractContext context)
    {
        if (hardpoint == null)
            return false;

        if (!CanAccessHardpointByContext(context))
            return false;

        if (hideHoverLabelWhenNotActionable && !IsInRange(context))
            return false;

        return true;
    }
}