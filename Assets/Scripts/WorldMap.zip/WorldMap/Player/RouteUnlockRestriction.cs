public sealed class RouteUnlockRestriction : ITravelRestriction
{
    public bool CanTravel(TravelRequest req, WorldMapSimContext ctx, WorldMapPlayerState player, out string reason)
    {
        var key = RouteKey.Make(req.fromNodeId, req.toNodeId);
        if (player.unlockedRoutes.Contains(key))
        {
            reason = "";
            return true;
        }

        // Allow intra-cluster travel by default, lock cross-cluster only (optional behavior)
        var from = ctx.GetNode(req.fromNodeId);
        var to = ctx.GetNode(req.toNodeId);
        if (from.ClusterId == to.ClusterId)
        {
            reason = "";
            return true;
        }

        reason = "Route locked. Requires star map.";
        return false;
    }
}
