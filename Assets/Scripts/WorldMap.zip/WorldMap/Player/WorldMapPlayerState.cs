using System.Collections.Generic;

[System.Serializable]
public sealed class WorldMapPlayerState
{
    public string currentNodeId;
    public int credits;
    public InventoryState inventory = new InventoryState();
    public HashSet<string> unlockedRoutes = new HashSet<string>(); // e.g. "nodeA|nodeB"
    public HashSet<int> unlockedClusters = new HashSet<int>(); // optional
}
