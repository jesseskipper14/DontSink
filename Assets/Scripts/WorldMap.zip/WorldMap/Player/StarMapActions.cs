public static class StarMapActions
{
    public static bool TryUnlockRoute(WorldMapPlayerState player, string fromNodeId, string toNodeId)
    {
        // simple: require one star map token item
        if (!player.inventory.Remove("item.star_map", 1))
            return false;

        player.unlockedRoutes.Add(RouteKey.Make(fromNodeId, toNodeId));
        return true;
    }
}
